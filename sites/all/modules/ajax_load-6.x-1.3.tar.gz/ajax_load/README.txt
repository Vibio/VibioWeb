Drupal ajax_load.module README.txt
==============================================================================


When loading new content via AJAX, there is the potential need to load
CSS and Javascript files and data not already available on the page.
Ajax Load is a helper module designed to handle this task.

