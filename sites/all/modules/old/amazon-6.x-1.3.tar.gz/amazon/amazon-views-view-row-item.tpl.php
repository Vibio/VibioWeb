<?php
// $Id: amazon-views-view-row-item.tpl.php,v 1.1.2.2 2010/02/25 06:41:30 rfay Exp $
/**
 * @file amazon-views-view-row-item.tpl.php
 * Default simple view template to display a single Amazon item.
 *
 *
 * @ingroup views_templates
 */
?>
<?php print $content; ?>
