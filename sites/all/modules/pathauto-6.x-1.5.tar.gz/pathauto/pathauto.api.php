<?php
// $Id: pathauto.api.php,v 1.2.4.2 2010/08/09 19:01:33 davereid Exp $

/**
 * @file
 * Documentation for pathauto API.
 *
 * @see hook_token_info
 * @see hook_tokens
 */

function hook_path_alias_types() {
}

function hook_pathauto($op) {
}

function hook_pathauto_bulkupdate() {
}

function hook_pathauto_alias_alter(&$alias, $context) {
}
